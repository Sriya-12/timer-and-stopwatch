let countdownInterval;
let remainingTime = 0;

function startCountdown() {
  const input = document.getElementById('countdown-input');
  const countdownDisplay = document.getElementById('countdown-display');
  const time = parseInt(input.value);

  remainingTime = time;

  countdownInterval = setInterval(() => {
    remainingTime--;

    if (remainingTime >= 0) {
      const minutes = Math.floor(remainingTime / 60);
      const seconds = remainingTime % 60;

      countdownDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    } else {
      clearInterval(countdownInterval);
      countdownDisplay.textContent = "Time's up!";
    }
  }, 1000);
}

function stopCountdown() {
  clearInterval(countdownInterval);
}

function resetCountdown() {
  clearInterval(countdownInterval);
  remainingTime = 0;
  document.getElementById('countdown-display').textContent = "00:00";
}


  let stopwatchInterval;
  let stopwatchTime = 0;
  
  function startStopwatch() {
    const stopwatchDisplay = document.getElementById('stopwatch-display');
    stopwatchInterval = setInterval(() => {
      stopwatchTime++;
      const minutes = Math.floor(stopwatchTime / 60 / 60);
      const seconds = Math.floor(stopwatchTime / 60) % 60;
      const milliseconds = stopwatchTime % 60;
  
      stopwatchDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}:${milliseconds.toString().padStart(2, '0')}`;
    }, 10);
  }
  
  function pauseStopwatch() {
    clearInterval(stopwatchInterval);
  }
  
  function resetStopwatch() {
    clearInterval(stopwatchInterval);
    stopwatchTime = 0;
    document.getElementById('stopwatch-display').textContent = '00:00:00';
  }
  